"""Automatic e-mail notifications through Zoho Mail (SMTP). Edit the settings just below."""
import os
import smtplib
import sqlite3
import ssl
import threading
from datetime import datetime
from email.message import EmailMessage
from email.utils import formataddr

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


# =====================================================================================
#  ZOHO MAIL SETTINGS  -  EDIT THESE 5 LINES
# =====================================================================================
SMTP_HOST = "smtp.zoho.in"                 # India account: smtp.zoho.in | Global: smtp.zoho.com | EU: smtp.zoho.eu
SMTP_PORT = 465                            # keep 465
MAIL_USER = "noreply@allwayhpc.com"        # the Zoho mailbox that SENDS all notifications
MAIL_PASSWORD = "PUT-PASSWORD-HERE"        # its password (or Zoho "app password" if 2-factor is on)
APP_BASE_URL = "http://localhost:5000"     # address your team opens in the browser, e.g. http://192.168.1.10:5000
# =====================================================================================
MAIL_FROM_NAME = "AHPC BOM System"
MAIL_SYNC = False                          # True = send in the foreground (only for debugging)


def config():
    return {"host": SMTP_HOST, "port": SMTP_PORT, "user": MAIL_USER, "password": MAIL_PASSWORD,
            "from_name": MAIL_FROM_NAME, "base_url": APP_BASE_URL.rstrip("/"), "sync": MAIL_SYNC}


def is_configured():
    c = config()
    return bool(c["user"] and c["password"] and c["password"] != "PUT-PASSWORD-HERE")


def _log(db_path, **row):
    try:
        con = sqlite3.connect(db_path, timeout=15)
        con.execute(
            """INSERT INTO email_log (created_at, event, ref, recipients, subject, status, error)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (datetime.now().isoformat(timespec="seconds"), row.get("event", ""), row.get("ref", ""),
             row.get("recipients", ""), row.get("subject", ""), row.get("status", ""), row.get("error", "")),
        )
        con.commit()
        con.close()
    except Exception as exc:  # logging must never break the app
        print("[mail] could not write email_log:", exc)


def _deliver(db_path, msg, recipients, event, ref):
    c = config()
    status, error = "SENT", ""
    try:
        if c["port"] == 465:
            with smtplib.SMTP_SSL(c["host"], c["port"], context=ssl.create_default_context(), timeout=30) as s:
                s.login(c["user"], c["password"])
                s.send_message(msg, to_addrs=recipients)
        else:
            with smtplib.SMTP(c["host"], c["port"], timeout=30) as s:
                s.starttls(context=ssl.create_default_context())
                s.login(c["user"], c["password"])
                s.send_message(msg, to_addrs=recipients)
    except Exception as exc:
        status, error = "FAILED", f"{type(exc).__name__}: {exc}"
        print("[mail] FAILED:", error)
    _log(db_path, event=event, ref=ref, recipients=", ".join(recipients), subject=msg["Subject"],
         status=status, error=error)


def send_mail(db_path, to, subject, html, text, reply_to=None, event="", ref=""):
    """to = list of (name, email). Duplicates are removed. Returns the list of addresses used."""
    seen, pairs = set(), []
    for name, email in to:
        email = (email or "").strip()
        if email and email.lower() not in seen:
            seen.add(email.lower())
            pairs.append((name or "", email))
    if not pairs:
        return []
    addrs = [e for _, e in pairs]
    c = config()
    if not is_configured():
        _log(db_path, event=event, ref=ref, recipients=", ".join(addrs), subject=subject,
             status="SKIPPED", error="Zoho mail is not configured (edit the settings at the top of notify.py)")
        return addrs

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = formataddr((c["from_name"], c["user"]))
    msg["To"] = ", ".join(formataddr(p) for p in pairs)
    if reply_to:
        msg["Reply-To"] = reply_to
    msg.set_content(text)
    msg.add_alternative(html, subtype="html")

    if c["sync"]:
        _deliver(db_path, msg, addrs, event, ref)
    else:
        threading.Thread(target=_deliver, args=(db_path, msg, addrs, event, ref), daemon=True).start()
    return addrs
