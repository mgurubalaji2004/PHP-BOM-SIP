"""
AHPC BOM & Quotation Management System
----------------------------------------
A self-contained internal web application implementing the workflow shown in
the AHPC BOM Software flowchart:

  Requirement -> Search Existing BOM/Components -> BOM Builder
  -> Pricing (Margin + GST) -> Internal Review -> Admin Approval
  -> Quotation Generation -> Order Status (PO / Cancelled)
  -> Procurement / Stock Check -> Work Order -> Packing/Delivery

Tech stack: Python + Flask + SQLite (single file DB). No external services
or internet access required. Easy to run on any internal server / laptop.

Run:
    pip install -r requirements.txt
    python app.py
Then open http://localhost:5000
"""

import io
import json
import os
import re
import secrets
import sqlite3
from datetime import datetime, date, timedelta
from functools import wraps

from flask import (
    Flask, render_template, request, redirect, url_for, session, flash, g, abort, send_file
)
from werkzeug.security import generate_password_hash, check_password_hash

import notify
import quote_docx

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "ahpc.db")



# Session signing key. Change this text to any long random sentence of your own.
SECRET_KEY = "ahpc-allway-hpc-bom-secret-2026-change-this-text"


app = Flask(__name__)
app.secret_key = SECRET_KEY

ROLES = ["Engineer", "Admin"]

# The team. Admins can assign work to anyone (including themselves); engineers do the work.
TEAM = [
    ("Gurubalaji", "gurubalaji@allwayhpc.com", "Engineer", "Guru@2026"),
    ("Saravana Kumar", "saravanakumar@allwayhpc.com", "Admin", "Saravana@2026"),
    ("Dinesh", "dinesh@allwayhpc.com", "Engineer", "Dinesh@2026"),
    ("Theepthithan", "theepthithan@allwayhpc.com", "Engineer", "Theep@2026"),
    ("Praveen", "praveen@allwayhpc.com", "Admin", "Praveen@2026"),
]
KIND_TABLE = {"req": "requirements", "bom": "boms", "quote": "quotations"}
KIND_LABEL = {"req": "Requirement", "bom": "BOM", "quote": "Quotation"}

# ---------------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------------

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    role TEXT NOT NULL,
    email TEXT,
    password_hash TEXT,
    active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS remarks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT NOT NULL,            -- req / bom / quote
    item_id INTEGER NOT NULL,
    author_id INTEGER,
    author_name TEXT,
    author_role TEXT,
    rtype TEXT DEFAULT 'REMARK',   -- REMARK / DELAY / ASSIGNMENT / SYSTEM
    body TEXT,
    created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_remarks_item ON remarks(kind, item_id);

CREATE TABLE IF NOT EXISTS email_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT,
    event TEXT,
    ref TEXT,
    recipients TEXT,
    subject TEXT,
    status TEXT,
    error TEXT
);

CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company TEXT NOT NULL,
    contact_person TEXT,
    email TEXT,
    phone TEXT
);

CREATE TABLE IF NOT EXISTS requirements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    req_number TEXT UNIQUE,
    customer_id INTEGER,
    sales_person TEXT,
    req_date TEXT,
    expected_delivery TEXT,
    title TEXT,
    description TEXT,
    status TEXT DEFAULT 'OPEN',
    created_at TEXT,
    FOREIGN KEY(customer_id) REFERENCES customers(id)
);

CREATE TABLE IF NOT EXISTS components (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    manufacturer TEXT,
    part_number TEXT,
    description TEXT,
    supplier TEXT,
    cost REAL DEFAULT 0,
    selling_price REAL DEFAULT 0,
    stock INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS boms (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bom_number TEXT,
    version INTEGER DEFAULT 1,
    parent_bom_id INTEGER,
    requirement_id INTEGER,
    customer_id INTEGER,
    title TEXT,
    status TEXT DEFAULT 'DRAFT',
    pricing_mode TEXT DEFAULT 'AUTOMATIC',
    margin_percent REAL DEFAULT 15,
    gst_percent REAL DEFAULT 18,
    review_comment TEXT,
    created_by TEXT,
    created_at TEXT,
    FOREIGN KEY(requirement_id) REFERENCES requirements(id),
    FOREIGN KEY(customer_id) REFERENCES customers(id)
);

CREATE TABLE IF NOT EXISTS bom_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bom_id INTEGER NOT NULL,
    component_id INTEGER,
    category TEXT,
    manufacturer TEXT,
    part_number TEXT,
    description TEXT,
    quantity REAL DEFAULT 1,
    unit_price REAL DEFAULT 0,
    FOREIGN KEY(bom_id) REFERENCES boms(id),
    FOREIGN KEY(component_id) REFERENCES components(id)
);

CREATE TABLE IF NOT EXISTS quotations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    quote_number TEXT UNIQUE,
    bom_id INTEGER,
    customer_id INTEGER,
    subtotal REAL,
    margin_amount REAL,
    gst_amount REAL,
    grand_total REAL,
    terms TEXT,
    status TEXT DEFAULT 'DRAFT',
    created_at TEXT,
    FOREIGN KEY(bom_id) REFERENCES boms(id),
    FOREIGN KEY(customer_id) REFERENCES customers(id)
);

CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_number TEXT UNIQUE,
    quote_id INTEGER,
    po_number TEXT,
    status TEXT DEFAULT 'AWAITING_PO',
    delivery_date TEXT,
    remarks TEXT,
    created_at TEXT,
    FOREIGN KEY(quote_id) REFERENCES quotations(id)
);

CREATE TABLE IF NOT EXISTS procurement (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER,
    component_id INTEGER,
    description TEXT,
    required_qty REAL,
    stock_qty REAL,
    shortage REAL,
    status TEXT DEFAULT 'PENDING',
    FOREIGN KEY(order_id) REFERENCES orders(id),
    FOREIGN KEY(component_id) REFERENCES components(id)
);
"""


def _add_col(db, table, col, decl):
    cols = [r[1] for r in db.execute(f"PRAGMA table_info({table})").fetchall()]
    if col not in cols:
        db.execute(f"ALTER TABLE {table} ADD COLUMN {col} {decl}")


def migrate(db):
    """Add the columns introduced in this version (safe to run on every start)."""
    _add_col(db, "customers", "address", "TEXT")
    _add_col(db, "users", "email", "TEXT")
    _add_col(db, "users", "password_hash", "TEXT")
    _add_col(db, "users", "active", "INTEGER DEFAULT 1")
    for t in ("requirements", "boms", "quotations"):
        _add_col(db, t, "assigned_to", "INTEGER")
        _add_col(db, t, "assigned_by", "INTEGER")
        _add_col(db, t, "assigned_at", "TEXT")
        _add_col(db, t, "due_date", "TEXT")
    _add_col(db, "requirements", "remarks", "TEXT")
    _add_col(db, "boms", "remarks", "TEXT")
    for col, decl in [("remarks", "TEXT"), ("to_company", "TEXT"), ("to_address", "TEXT"), ("subject", "TEXT"),
                      ("specs", "TEXT"), ("total_price", "REAL"), ("gst_percent", "REAL"),
                      ("quote_date", "TEXT"), ("terms_json", "TEXT"), ("updated_at", "TEXT")]:
        _add_col(db, "quotations", col, decl)
    # Quantities are whole numbers and prices are whole rupees (no decimals)
    db.execute("UPDATE bom_items SET quantity = MAX(1, CAST(ROUND(quantity) AS INTEGER)), unit_price = CAST(ROUND(unit_price) AS INTEGER)")
    db.execute("UPDATE components SET cost = CAST(ROUND(cost) AS INTEGER), selling_price = CAST(ROUND(selling_price) AS INTEGER)")
    db.commit()


def init_db():
    first_time = not os.path.exists(DB_PATH)
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    db.executescript(SCHEMA)
    db.commit()
    if first_time:
        seed(db)
    migrate(db)
    ensure_team(db)
    db.close()


def _new_password():
    alphabet = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return "".join(secrets.choice(alphabet) for _ in range(10))


def reset_team_passwords(db):
    """Set every team member back to the starting password listed in TEAM (also re-activates the account)."""
    for name, email, role, default_pw in TEAM:
        row = db.execute("SELECT id FROM users WHERE lower(email)=?", (email.lower(),)).fetchone()
        if row is None:
            db.execute("INSERT INTO users (name, role, email, password_hash, active) VALUES (?,?,?,?,1)",
                       (name, role, email, generate_password_hash(default_pw)))
        else:
            db.execute("UPDATE users SET name=?, role=?, password_hash=?, active=1 WHERE id=?",
                       (name, role, generate_password_hash(default_pw), row["id"]))
    db.commit()


def ensure_team(db):
    """Create the 5 logins listed in TEAM (password written there). Old demo users (no e-mail) are removed.
    Existing users keep the password they have (so changed passwords are never overwritten)."""
    db.execute("DELETE FROM users WHERE email IS NULL OR email = ''")
    for name, email, role, default_pw in TEAM:
        row = db.execute("SELECT * FROM users WHERE lower(email)=?", (email.lower(),)).fetchone()
        if row is None:
            db.execute("INSERT INTO users (name, role, email, password_hash, active) VALUES (?,?,?,?,1)",
                       (name, role, email, generate_password_hash(default_pw)))
        else:
            db.execute("UPDATE users SET name=?, role=? WHERE id=?", (name, role, row["id"]))
            if not row["password_hash"]:
                db.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(default_pw), row["id"]))
    db.commit()


def seed(db):
    """Seed some sample data so the system is usable immediately."""
    db.executemany(
        "INSERT INTO customers (company, contact_person, email, phone) VALUES (?, ?, ?, ?)",
        [
            ("ABC Technologies Pvt Ltd", "Arjun Rao", "arjun@abctech.com", "9876543210"),
            ("XYZ Research Labs", "Divya Menon", "divya@xyzlabs.in", "9123456780"),
        ],
    )
    components = [
        ("CPU", "AMD", "EPYC 9554", "64-core Server CPU", "Local Distributor", 250000, 285000, 6),
        ("CPU", "Intel", "Xeon W5-2455X", "12-core Workstation CPU", "Local Distributor", 90000, 105000, 10),
        ("GPU", "NVIDIA", "H200 SXM", "141GB HBM3e AI GPU", "OEM Partner", 2200000, 2450000, 8),
        ("GPU", "NVIDIA", "RTX 6000 Ada", "48GB Workstation GPU", "OEM Partner", 420000, 470000, 4),
        ("Motherboard", "Gigabyte", "MW53-HP0", "Server Motherboard", "Local Distributor", 55000, 65000, 12),
        ("RAM", "Samsung", "64GB DDR5 ECC", "Server RAM Module", "Local Distributor", 28000, 32000, 40),
        ("Storage", "Samsung", "PM9A3 3.84TB", "Enterprise NVMe SSD", "Local Distributor", 48000, 54000, 20),
        ("Networking", "NVIDIA", "ConnectX-7 400G", "InfiniBand NIC", "OEM Partner", 180000, 205000, 6),
        ("Chassis", "Supermicro", "SYS-4029GP", "4U GPU Server Chassis", "OEM Partner", 150000, 172000, 3),
        ("PSU", "Delta", "3000W Redundant", "Server Power Supply", "Local Distributor", 35000, 40000, 15),
    ]
    db.executemany(
        """INSERT INTO components
           (category, manufacturer, part_number, description, supplier, cost, selling_price, stock)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        components,
    )
    db.commit()


# ---------------------------------------------------------------------------
# Numbering helpers
# ---------------------------------------------------------------------------

def next_number(db, table, number_col, prefix):
    year = datetime.now().year
    like_pattern = f"{prefix}-{year}-%"
    row = db.execute(
        f"SELECT {number_col} FROM {table} WHERE {number_col} LIKE ? ORDER BY id DESC LIMIT 1",
        (like_pattern,),
    ).fetchone()
    if row and row[0]:
        try:
            seq = int(row[0].split("-")[-1]) + 1
        except ValueError:
            seq = 1
    else:
        seq = 1
    return f"{prefix}-{year}-{seq:03d}"


def next_quote_number(db):
    year = datetime.now().year
    like_pattern = f"AHPC/QTN/{year}/%"
    row = db.execute(
        "SELECT quote_number FROM quotations WHERE quote_number LIKE ? ORDER BY id DESC LIMIT 1",
        (like_pattern,),
    ).fetchone()
    if row and row[0]:
        try:
            seq = int(row[0].split("/")[-1]) + 1
        except ValueError:
            seq = 1
    else:
        seq = 1
    return f"AHPC/QTN/{year}/{seq:05d}"


# ---------------------------------------------------------------------------
# Auth (lightweight - internal tool, name + role based)
# ---------------------------------------------------------------------------

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login", next=request.path))
        return f(*args, **kwargs)
    return wrapper


def roles_required(*roles):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            if "user_id" not in session:
                return redirect(url_for("login", next=request.path))
            if session.get("role") not in roles and session.get("role") != "Admin":
                flash(f"This action requires role: {', '.join(roles)}", "error")
                return redirect(url_for("dashboard"))
            return f(*args, **kwargs)
        return wrapper
    return decorator


@app.before_request
def load_current_user():
    """Re-read the logged-in user from the DB on every request (role changes / deactivation apply at once)."""
    g.user = None
    if request.endpoint in (None, "static"):
        return
    uid = session.get("user_id")
    if uid:
        u = get_db().execute("SELECT * FROM users WHERE id=? AND active=1", (uid,)).fetchone()
        if u is None:
            session.clear()
        else:
            g.user = u
            session["user_name"], session["role"] = u["name"], u["role"]


def inr(value, decimals=0):
    """Indian digit grouping: 514050 -> 5,14,050 (no decimals unless asked)."""
    try:
        v = float(value or 0)
    except (TypeError, ValueError):
        return value
    s = f"{abs(v):.{decimals}f}"
    whole, _, dec = s.partition(".")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        whole = ",".join(parts) + "," + tail
    return ("-" if v < 0 else "") + whole + ("." + dec if dec else "")


app.jinja_env.filters["inr"] = inr


def highlight(text, words):
    """HTML-escape text and wrap every search word in <mark>."""
    from markupsafe import Markup, escape
    out = str(escape(text or ""))
    for w in sorted(set(words or []), key=len, reverse=True):
        out = re.sub("(" + re.escape(str(escape(w))) + ")", r"<mark>\1</mark>", out, flags=re.I)
    return Markup(out)


app.jinja_env.filters["hl"] = highlight


def to_int(value, default=0, minimum=None):
    """Parse '3', '3.0', '1,50,000' ... into a whole number."""
    try:
        n = int(round(float(str(value).replace(",", "").strip())))
    except (TypeError, ValueError):
        n = default
    if minimum is not None:
        n = max(minimum, n)
    return n


@app.context_processor
def inject_user():
    return dict(current_user=session.get("user_name"), current_role=session.get("role"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password") or ""
        u = get_db().execute("SELECT * FROM users WHERE lower(email)=? AND active=1", (email,)).fetchone()
        if u is None or not u["password_hash"] or not check_password_hash(u["password_hash"], password):
            flash("Wrong e-mail or password.", "error")
            return render_template("login.html", email=email), 401
        session.clear()
        session["user_id"], session["user_name"], session["role"] = u["id"], u["name"], u["role"]
        flash(f"Welcome, {u['name']} ({u['role']})", "success")
        nxt = request.args.get("next") or ""
        return redirect(nxt if nxt.startswith("/") and not nxt.startswith("//") else url_for("dashboard"))
    return render_template("login.html", email="")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/account/password", methods=["GET", "POST"])
@login_required
def change_password():
    db = get_db()
    if request.method == "POST":
        u = db.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
        new = request.form.get("new_password") or ""
        if not check_password_hash(u["password_hash"], request.form.get("old_password") or ""):
            flash("Current password is wrong.", "error")
        elif len(new) < 8:
            flash("New password must be at least 8 characters.", "error")
        elif new != request.form.get("confirm_password"):
            flash("New password and confirmation do not match.", "error")
        else:
            db.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new), u["id"]))
            db.commit()
            flash("Password changed.", "success")
            return redirect(url_for("dashboard"))
    return render_template("change_password.html")


@app.route("/team")
@roles_required("Admin")
def team():
    db = get_db()
    users = db.execute("SELECT * FROM users ORDER BY role, name").fetchall()
    log = db.execute("SELECT * FROM email_log ORDER BY id DESC LIMIT 100").fetchall()
    return render_template("team.html", users=users, log=log, mail_ok=notify.is_configured(), mail=notify.config())


@app.route("/team/<int:user_id>/reset_password", methods=["POST"])
@roles_required("Admin")
def reset_password(user_id):
    db = get_db()
    u = db.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    if not u:
        abort(404)
    pw = _new_password()
    db.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(pw), user_id))
    db.commit()
    flash(f"New password for {u['name']} ({u['email']}): {pw}  - share it with them now; it is not shown again.", "success")
    return redirect(url_for("team"))


@app.route("/team/test_mail", methods=["POST"])
@roles_required("Admin")
def team_test_mail():
    db = get_db()
    me = db.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
    subject = "[AHPC] Test e-mail from the BOM system"
    body = "If you can read this, Zoho Mail notifications are working."
    sent = notify.send_mail(DB_PATH, [(me["name"], me["email"])], subject,
                            f"<p>{body}</p>", body, event="TEST", ref="")
    flash(("Test e-mail queued to " + ", ".join(sent) + " - check the log below for the result.") if sent
          else "No recipient.", "success")
    return redirect(url_for("team"))


# ---------------------------------------------------------------------------
# Assignment, remarks (conversation thread) and automatic e-mail notifications
# ---------------------------------------------------------------------------

def team_users(db, only_active=True):
    return db.execute("SELECT * FROM users WHERE active=1 ORDER BY role DESC, name" if only_active
                      else "SELECT * FROM users ORDER BY name").fetchall()


def admin_users(db):
    return db.execute("SELECT * FROM users WHERE role='Admin' AND active=1").fetchall()


def user_by_id(db, uid):
    return db.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone() if uid else None


def item_info(db, kind, item_id):
    """Everything a notification (or the thread panel) needs to know about a requirement / BOM / quotation."""
    table = KIND_TABLE.get(kind)
    if not table:
        abort(404)
    r = db.execute(f"SELECT * FROM {table} WHERE id=?", (item_id,)).fetchone()
    if r is None:
        abort(404)
    if kind == "req":
        ref, title, path = r["req_number"], r["title"], url_for("requirement_edit", req_id=item_id)
        cust = r["customer_id"]
    elif kind == "bom":
        ref, title, path = f"{r['bom_number']} v{r['version']}", r["title"], url_for("bom_detail", bom_id=item_id)
        cust = r["customer_id"]
    else:
        ref, title, path = r["quote_number"], r["subject"] or "Quotation", url_for("quote_view", quote_id=item_id)
        cust = r["customer_id"]
    c = db.execute("SELECT company FROM customers WHERE id=?", (cust,)).fetchone() if cust else None
    base = notify.config()["base_url"] or (request.host_url.rstrip("/") if request else "")
    return dict(kind=kind, id=item_id, label=KIND_LABEL[kind], ref=ref, title=title or "", path=path,
                url=base + path, company=c["company"] if c else "", assigned_to=r["assigned_to"],
                due_date=r["due_date"], row=r)


def thread_for(kind, item_id):
    """Jinja helper: (info, remarks) for the conversation panel."""
    db = get_db()
    info = item_info(db, kind, item_id)
    remarks = db.execute("SELECT * FROM remarks WHERE kind=? AND item_id=? ORDER BY id DESC", (kind, item_id)).fetchall()
    assignee = user_by_id(db, info["assigned_to"])
    return dict(info=info, remarks=remarks, assignee=assignee, users=team_users(db),
                overdue=bool(info["due_date"] and info["due_date"] < date.today().isoformat()))


app.jinja_env.globals["thread_for"] = thread_for
app.jinja_env.globals["team_users"] = lambda: team_users(get_db())


def add_remark(db, kind, item_id, user, rtype, body):
    db.execute(
        """INSERT INTO remarks (kind, item_id, author_id, author_name, author_role, rtype, body, created_at)
           VALUES (?,?,?,?,?,?,?,?)""",
        (kind, item_id, user["id"] if user else None, user["name"] if user else "System",
         user["role"] if user else "", rtype, body, datetime.now().isoformat(timespec="seconds")))


def notify_event(db, kind, item_id, event, headline, message, actor=None, to_admins=True, to_assignee=True,
                 extra_users=(), include_actor=False, details=None):
    """E-mail everyone concerned with an item. Recipients = assignee + all admins (+ extras), without the person
    who did the action (unless include_actor). Returns the addresses used."""
    info = item_info(db, kind, item_id)
    people = {}
    if to_assignee and info["assigned_to"]:
        u = user_by_id(db, info["assigned_to"])
        if u and u["active"]:
            people[u["id"]] = u
    if to_admins:
        for u in admin_users(db):
            people[u["id"]] = u
    for u in extra_users:
        if u and u["active"]:
            people[u["id"]] = u
    if actor is not None and not include_actor:
        people.pop(actor["id"], None)
    if not people:
        return []
    assignee = user_by_id(db, info["assigned_to"])
    rows = [("Type", info["label"]), ("Reference", info["ref"]), ("Title", info["title"] or "-"),
            ("Customer", info["company"] or "-"),
            ("Assigned to", assignee["name"] if assignee else "Not assigned yet"),
            ("Due date", info["due_date"] or "-")] + list(details or [])
    by = f"{actor['name']} ({actor['role']})" if actor else "System"
    subject = f"[AHPC] {headline}: {info['ref']} - {info['title'] or info['label']}"
    html = render_template("email_notify.html", headline=headline, message=message, rows=rows, by=by,
                           link=info["url"], when=datetime.now().strftime("%d %b %Y, %I:%M %p"))
    text = (f"{headline}\n\n{message}\n\n" + "\n".join(f"{k}: {v}" for k, v in rows)
            + f"\n\nBy: {by}\nOpen: {info['url']}\n")
    return notify.send_mail(DB_PATH, [(u["name"], u["email"]) for u in people.values()], subject, html, text,
                            reply_to=actor["email"] if actor else None, event=event, ref=info["ref"])


def current_user_row(db):
    return user_by_id(db, session.get("user_id"))


def do_assign(db, kind, item_id, assignee_id, due_date, note, actor):
    """Assign (or re-assign) an item, record it in the thread and e-mail the people concerned."""
    table = KIND_TABLE[kind]
    old = db.execute(f"SELECT assigned_to FROM {table} WHERE id=?", (item_id,)).fetchone()
    old_id = old["assigned_to"] if old else None
    db.execute(f"UPDATE {table} SET assigned_to=?, assigned_by=?, assigned_at=?, due_date=? WHERE id=?",
               (assignee_id, actor["id"], datetime.now().isoformat(timespec="seconds"), due_date or None, item_id))
    assignee = user_by_id(db, assignee_id)
    line = f"Assigned to {assignee['name']}" + (f", due {due_date}" if due_date else "")
    if note:
        line += f". Instruction: {note}"
    add_remark(db, kind, item_id, actor, "ASSIGNMENT", line)
    db.commit()
    extra = [assignee]
    previous = user_by_id(db, old_id) if old_id and old_id != assignee_id else None
    if previous:
        extra.append(previous)
    msg = (f"{actor['name']} has assigned this {KIND_LABEL[kind].lower()} to "
           f"{'themselves' if assignee['id'] == actor['id'] else assignee['name']}."
           + (f" Due date: {due_date}." if due_date else "")
           + (f"\n\nInstruction: {note}" if note else "")
           + (f"\n\n(Previously assigned to {previous['name']}.)" if previous else ""))
    notify_event(db, kind, item_id, "ASSIGNED", "Assigned" if not previous else "Re-assigned", msg, actor=actor,
                 extra_users=extra, include_actor=True)


@app.route("/assign/<kind>/<int:item_id>", methods=["POST"])
@roles_required("Admin")
def assign(kind, item_id):
    db = get_db()
    if kind not in KIND_TABLE:
        abort(404)
    assignee = user_by_id(db, request.form.get("assignee_id", type=int))
    if not assignee or not assignee["active"]:
        flash("Choose a person to assign to.", "error")
    else:
        do_assign(db, kind, item_id, assignee["id"], request.form.get("due_date"),
                  (request.form.get("note") or "").strip(), current_user_row(db))
        flash(f"Assigned to {assignee['name']}. They have been notified by e-mail.", "success")
    return redirect(request.form.get("next") or request.referrer or url_for("dashboard"))


@app.route("/remarks/<kind>/<int:item_id>", methods=["POST"])
@login_required
def save_remarks(kind, item_id):
    """Add a remark or a 'reason for delay' to a requirement / BOM / quotation and e-mail it."""
    db = get_db()
    if kind not in KIND_TABLE:
        abort(404)
    body = (request.form.get("remarks") or "").strip()
    nxt = request.form.get("next") or request.referrer or url_for("dashboard")
    if not body:
        flash("Please type a remark first.", "error")
        return redirect(nxt)
    me = current_user_row(db)
    rtype = "DELAY" if request.form.get("rtype") == "DELAY" else "REMARK"
    new_due = (request.form.get("new_due") or "").strip()
    text = body + (f" (revised due date: {new_due})" if rtype == "DELAY" and new_due else "")
    add_remark(db, kind, item_id, me, rtype, text)
    table = KIND_TABLE[kind]
    db.execute(f"UPDATE {table} SET remarks=? WHERE id=?", (("Delay: " if rtype == "DELAY" else "") + body, item_id))
    if rtype == "DELAY" and new_due:
        db.execute(f"UPDATE {table} SET due_date=? WHERE id=?", (new_due, item_id))
    db.commit()
    if rtype == "DELAY":
        headline, event = "Reason for delay", "DELAY"
        msg = f"{me['name']} has reported a delay:\n\n{text}"
    elif me["role"] == "Admin":
        headline, event = "Remark from Admin", "REMARK_ADMIN"
        msg = f"{me['name']} (Admin) added a remark:\n\n{text}"
    else:
        headline, event = "Remark to Admin", "REMARK_ENGINEER"
        msg = f"{me['name']} (Engineer) added a remark:\n\n{text}"
    notify_event(db, kind, item_id, event, headline, msg, actor=me)
    flash("Remark saved and e-mailed.", "success")
    return redirect(nxt)


# ---------------------------------------------------------------------------
# Customers helper (used by Requirement / BOM forms to add a customer on the fly)
# ---------------------------------------------------------------------------

def resolve_customer(db):
    """Return the customer id from a form. Value '__new__' creates a customer from the inline fields."""
    cid = request.form.get("customer_id")
    if cid == "__new__":
        company = (request.form.get("new_company") or "").strip()
        if not company:
            return None
        cur = db.execute(
            "INSERT INTO customers (company, contact_person, email, phone, address) VALUES (?, ?, ?, ?, ?)",
            (company, request.form.get("new_contact_person"), request.form.get("new_email"),
             request.form.get("new_phone"), request.form.get("new_address")),
        )
        return cur.lastrowid
    return int(cid) if cid else None


# ---------------------------------------------------------------------------
# Dashboard - pending quotes with engineer remarks
# ---------------------------------------------------------------------------

PENDING_STAGE = {
    "DRAFT": ("BOM being prepared", "Engineer"),
    "UNDER_REVIEW": ("BOM under internal review", "Admin"),
    "APPROVED": ("BOM approved - quotation not generated", "Sales"),
    "REVISION_REQUIRED": ("Revision required", "Engineer"),
}


def pending_quotes(db):
    """Everything that has not yet reached a SENT quotation, with who it is pending with."""
    rows = []
    # 1. requirements without any BOM
    for r in db.execute(
        """SELECT r.*, c.company FROM requirements r LEFT JOIN customers c ON c.id=r.customer_id
           WHERE NOT EXISTS (SELECT 1 FROM boms b WHERE b.requirement_id=r.id) ORDER BY r.id DESC"""
    ).fetchall():
        rows.append(dict(kind="req", id=r["id"], ref=r["req_number"], title=r["title"], company=r["company"],
                         stage="Requirement received - BOM not started", pending_by="Engineer",
                         remarks=r["remarks"], since=(r["created_at"] or "")[:10],
                         link=url_for("bom_search", requirement_id=r["id"])))
    # 2. latest version of every BOM that has not been quoted yet
    for b in db.execute(
        """SELECT b.*, c.company FROM boms b LEFT JOIN customers c ON c.id=b.customer_id
           WHERE b.status != 'QUOTED' AND b.status != 'REVISION_REQUIRED' AND COALESCE(b.created_by,'') != 'Excel import'
             AND NOT EXISTS (SELECT 1 FROM boms n WHERE n.bom_number=b.bom_number AND n.version>b.version)
           ORDER BY b.id DESC"""
    ).fetchall():
        stage, who = PENDING_STAGE.get(b["status"], (b["status"], "Engineer"))
        rows.append(dict(kind="bom", id=b["id"], ref=f"{b['bom_number']} v{b['version']}", title=b["title"],
                         company=b["company"], stage=stage, pending_by=who, remarks=b["remarks"],
                         since=(b["created_at"] or "")[:10], link=url_for("bom_detail", bom_id=b["id"])))
    # 3. quotations generated but not yet sent
    for q in db.execute(
        """SELECT q.*, c.company FROM quotations q LEFT JOIN customers c ON c.id=q.customer_id
           WHERE q.status='DRAFT' ORDER BY q.id DESC"""
    ).fetchall():
        rows.append(dict(kind="quote", id=q["id"], ref=q["quote_number"], title=q["subject"] or "Quotation",
                         company=q["company"], stage="Quotation draft - not yet sent to customer",
                         pending_by="Sales", remarks=q["remarks"], since=(q["created_at"] or "")[:10],
                         link=url_for("quote_view", quote_id=q["id"])))
    # who is it assigned to, when is it due, what was the last remark
    today = date.today().isoformat()
    for r in rows:
        t = KIND_TABLE[r["kind"]]
        a = db.execute(f"SELECT x.assigned_to, x.due_date, u.name AS aname FROM {t} x LEFT JOIN users u ON u.id=x.assigned_to WHERE x.id=?",
                       (r["id"],)).fetchone()
        r["assignee_id"], r["assignee"], r["due"] = a["assigned_to"], a["aname"], a["due_date"]
        r["overdue"] = bool(a["due_date"] and a["due_date"] < today)
        last = db.execute("SELECT * FROM remarks WHERE kind=? AND item_id=? AND rtype IN ('REMARK','DELAY') ORDER BY id DESC LIMIT 1",
                          (r["kind"], r["id"])).fetchone()
        r["last_remark"] = last
    return rows


@app.route("/")
@login_required
def dashboard():
    db = get_db()
    pending = pending_quotes(db)
    mine = request.args.get("mine") == "1"
    my_open = [p for p in pending if p["assignee_id"] == session.get("user_id")]
    if mine:
        pending = my_open
    counts = {
        "requirements": db.execute("SELECT COUNT(*) FROM requirements").fetchone()[0],
        "boms": db.execute("SELECT COUNT(DISTINCT bom_number) FROM boms").fetchone()[0],
        "pending": len(pending_quotes(db)),
        "quotes": db.execute("SELECT COUNT(*) FROM quotations").fetchone()[0],
    }
    return render_template("dashboard.html", counts=counts, pending=pending, mine=mine, my_count=len(my_open))


# ---------------------------------------------------------------------------
# Analytics dashboard (graphs)
# ---------------------------------------------------------------------------

def _month_keys(n=6):
    today = date.today().replace(day=1)
    keys = []
    y, m = today.year, today.month
    for _ in range(n):
        keys.append(f"{y:04d}-{m:02d}")
        m -= 1
        if m == 0:
            m, y = 12, y - 1
    return list(reversed(keys))


@app.route("/analytics")
@login_required
def analytics():
    db = get_db()
    q = lambda sql, *a: db.execute(sql, a).fetchall()
    latest = """NOT EXISTS (SELECT 1 FROM boms n WHERE n.bom_number=b.bom_number AND n.version>b.version)"""

    months = _month_keys(6)
    def monthly(table, col="created_at"):
        data = {m: 0 for m in months}
        for r in q(f"SELECT substr({col},1,7) m, COUNT(*) c FROM {table} GROUP BY m"):
            if r["m"] in data:
                data[r["m"]] = r["c"]
        return [data[m] for m in months]

    qval = {m: 0 for m in months}
    for r in q("SELECT substr(created_at,1,7) m, SUM(grand_total) s FROM quotations GROUP BY m"):
        if r["m"] in qval:
            qval[r["m"]] = round(r["s"] or 0)

    status_rows = q(f"SELECT status, COUNT(*) c FROM boms b WHERE {latest} GROUP BY status")
    bom_status = [[r["status"].replace("_", " ").title(), r["c"]] for r in status_rows]

    cust_rows = q("""SELECT c.company, SUM(qt.grand_total) s, COUNT(*) n FROM quotations qt
                     LEFT JOIN customers c ON c.id=qt.customer_id GROUP BY c.company ORDER BY s DESC LIMIT 8""")
    by_customer = [[r["company"] or "-", round(r["s"] or 0)] for r in cust_rows]

    cat_rows = q(f"""SELECT it.category cat, SUM(it.quantity*it.unit_price) s FROM bom_items it
                     JOIN boms b ON b.id=it.bom_id WHERE {latest} GROUP BY it.category ORDER BY s DESC LIMIT 10""")
    by_category = [[r["cat"] or "Other", round(r["s"] or 0)] for r in cat_rows]

    quote_rows = q("""SELECT quote_number, subtotal, margin_amount, gst_amount FROM quotations ORDER BY id DESC LIMIT 8""")
    quote_split = [["#" + re.sub(r"\D", "", r["quote_number"])[-5:], round(r["subtotal"] or 0), round(r["margin_amount"] or 0),
                    round(r["gst_amount"] or 0)] for r in reversed(quote_rows)]

    pending = pending_quotes(db)
    by_owner = {}
    for p in pending:
        by_owner[p["pending_by"]] = by_owner.get(p["pending_by"], 0) + 1

    n_req = db.execute("SELECT COUNT(*) FROM requirements").fetchone()[0]
    n_bom = db.execute("SELECT COUNT(DISTINCT bom_number) FROM boms").fetchone()[0]
    n_appr = db.execute(f"SELECT COUNT(*) FROM boms b WHERE {latest} AND status IN ('APPROVED','QUOTED')").fetchone()[0]
    n_quote = db.execute("SELECT COUNT(*) FROM quotations").fetchone()[0]
    n_sent = db.execute("SELECT COUNT(*) FROM quotations WHERE status='SENT'").fetchone()[0]
    total_val = db.execute("SELECT COALESCE(SUM(grand_total),0) FROM quotations").fetchone()[0]
    sent_val = db.execute("SELECT COALESCE(SUM(grand_total),0) FROM quotations WHERE status='SENT'").fetchone()[0]

    sales_rows = q("SELECT COALESCE(sales_person,'-') sp, COUNT(*) c FROM requirements GROUP BY sp ORDER BY c DESC LIMIT 8")

    data = {
        "months": months,
        "req_m": monthly("requirements"), "bom_m": monthly("boms"), "quote_m": monthly("quotations"),
        "quote_value_m": [qval[m] for m in months],
        "funnel": [["Requirements", n_req], ["BOMs", n_bom], ["Approved", n_appr], ["Quotes", n_quote], ["Sent", n_sent]],
        "bom_status": bom_status, "by_customer": by_customer, "by_category": by_category,
        "quote_split": quote_split, "pending_owner": [[k, v] for k, v in by_owner.items()],
        "by_sales": [[r["sp"], r["c"]] for r in sales_rows],
    }
    kpis = {
        "requirements": n_req, "boms": n_bom, "quotes": n_quote, "pending": len(pending),
        "quote_value": total_val, "sent_value": sent_val,
        "avg_quote": (total_val / n_quote) if n_quote else 0,
        "customers": db.execute("SELECT COUNT(*) FROM customers").fetchone()[0],
        "conversion": round(100.0 * n_sent / n_req) if n_req else 0,
    }
    return render_template("analytics.html", data=data, kpis=kpis)
# ---------------------------------------------------------------------------
# Step 1: Customers
# ---------------------------------------------------------------------------

@app.route("/customers", methods=["GET", "POST"])
@login_required
def customers():
    db = get_db()
    if request.method == "POST":
        db.execute(
            "INSERT INTO customers (company, contact_person, email, phone, address) VALUES (?, ?, ?, ?, ?)",
            (request.form["company"], request.form.get("contact_person"),
             request.form.get("email"), request.form.get("phone"), request.form.get("address")),
        )
        db.commit()
        flash("Customer added.", "success")
        return redirect(url_for("customers"))
    rows = db.execute("SELECT * FROM customers ORDER BY company").fetchall()
    return render_template("customers.html", customers=rows)



# ---------------------------------------------------------------------------
# Step 2: Requirement entry
# ---------------------------------------------------------------------------

@app.route("/requirements")
@login_required
def requirements_list():
    db = get_db()
    rows = db.execute(
        """SELECT r.*, c.company FROM requirements r
           LEFT JOIN customers c ON c.id = r.customer_id
           ORDER BY r.id DESC"""
    ).fetchall()
    return render_template("requirements_list.html", requirements=rows)


@app.route("/requirements/new", methods=["GET", "POST"])
@login_required
def requirement_new():
    db = get_db()
    if request.method == "POST":
        customer_id = resolve_customer(db)
        if not customer_id:
            flash("Please select a customer, or enter the company name of the new customer.", "error")
            return redirect(url_for("requirement_new"))
        req_number = next_number(db, "requirements", "req_number", "REQ")
        cur = db.execute(
            """INSERT INTO requirements
               (req_number, customer_id, sales_person, req_date, expected_delivery, title, description, status, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, 'OPEN', ?)""",
            (
                req_number, customer_id,
                request.form.get("sales_person") or session.get("user_name"),
                request.form.get("req_date") or date.today().isoformat(),
                request.form.get("expected_delivery"),
                request.form.get("title"),
                request.form.get("description"),
                datetime.now().isoformat(timespec="seconds"),
            ),
        )
        db.commit()
        me = current_user_row(db)
        new_id = cur.lastrowid
        assignee_id = request.form.get("assignee_id", type=int)
        if me["role"] == "Admin" and assignee_id and user_by_id(db, assignee_id):
            do_assign(db, "req", new_id, assignee_id, request.form.get("due_date"),
                      (request.form.get("note") or "").strip(), me)
        else:
            notify_event(db, "req", new_id, "REQ_NEW", "New requirement received (not assigned yet)",
                         f"{me['name']} entered a new customer requirement. An admin needs to assign it to an engineer.\n\n"
                         + (request.form.get("description") or ""), actor=me, to_assignee=False)
        flash(f"Requirement {req_number} created.", "success")
        return redirect(url_for("bom_search", requirement_id=new_id))
    customers_rows = db.execute("SELECT * FROM customers ORDER BY company").fetchall()
    return render_template("requirement_new.html", customers=customers_rows)


@app.route("/requirements/<int:req_id>/edit", methods=["GET", "POST"])
@login_required
def requirement_edit(req_id):
    db = get_db()
    r = db.execute("SELECT * FROM requirements WHERE id=?", (req_id,)).fetchone()
    if not r:
        abort(404)
    if request.method == "POST":
        customer_id = resolve_customer(db) or r["customer_id"]
        db.execute(
            """UPDATE requirements SET customer_id=?, sales_person=?, req_date=?, expected_delivery=?, title=?,
               description=? WHERE id=?""",
            (customer_id, request.form.get("sales_person"), request.form.get("req_date"),
             request.form.get("expected_delivery"), request.form.get("title"),
             request.form.get("description"), req_id),
        )
        db.commit()
        notify_event(db, "req", req_id, "REQ_EDIT", "Requirement updated",
                     f"{session.get('user_name')} edited the requirement details.", actor=current_user_row(db))
        flash("Requirement updated.", "success")
        return redirect(url_for("requirements_list"))
    customers_rows = db.execute("SELECT * FROM customers ORDER BY company").fetchall()
    return render_template("requirement_new.html", customers=customers_rows, req=r)


# ---------------------------------------------------------------------------
# Step 3: Component database / search
# ---------------------------------------------------------------------------

@app.route("/components", methods=["GET", "POST"])
@login_required
def components():
    db = get_db()
    if request.method == "POST":
        db.execute(
            """INSERT INTO components (category, manufacturer, part_number, description, supplier, cost, selling_price, stock)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                request.form["category"], request.form.get("manufacturer"),
                request.form.get("part_number"), request.form.get("description"),
                request.form.get("supplier"),
                to_int(request.form.get("cost")),
                to_int(request.form.get("selling_price")),
                int(request.form.get("stock") or 0),
            ),
        )
        db.commit()
        flash("Component added.", "success")
        return redirect(url_for("components"))

    q = request.args.get("q", "").strip()
    category = request.args.get("category", "").strip()
    sql = "SELECT * FROM components WHERE 1=1"
    params = []
    if q:
        sql += " AND (manufacturer LIKE ? OR part_number LIKE ? OR description LIKE ? OR category LIKE ?)"
        params += [f"%{q}%"] * 4
    if category:
        sql += " AND category = ?"
        params.append(category)
    sql += " ORDER BY category, manufacturer"
    rows = db.execute(sql, params).fetchall()
    categories = [r[0] for r in db.execute("SELECT DISTINCT category FROM components ORDER BY category").fetchall()]
    return render_template("components.html", components=rows, categories=categories, q=q, category=category)


def rebuild_components(db):
    """Replace the whole Component database with the distinct components used in all BOMs
    (category + model). Price = the most frequent non-zero unit price used for it."""
    from collections import Counter, defaultdict
    groups = defaultdict(lambda: {"cat": "", "model": "", "mfr": "", "desc": "", "prices": Counter(), "n": 0})
    for it in db.execute("SELECT * FROM bom_items ORDER BY id").fetchall():
        model = re.sub(r"\s+", " ", (it["part_number"] or "")).strip()
        cat = (it["category"] or "").strip()
        if not model or not cat:
            continue
        key = (cat.lower(), re.sub(r"[^a-z0-9]", "", model.lower()))
        g = groups[key]
        g["cat"], g["model"] = g["cat"] or cat, g["model"] or model
        g["mfr"] = g["mfr"] or (it["manufacturer"] or "")
        g["desc"] = g["desc"] or (it["description"] or "")
        g["n"] += 1
        if (it["unit_price"] or 0) > 0:
            g["prices"][int(round(it["unit_price"]))] += 1
    db.execute("UPDATE bom_items SET component_id=NULL")
    db.execute("DELETE FROM components")
    for g in sorted(groups.values(), key=lambda x: (x["cat"].lower(), x["model"].lower())):
        price = g["prices"].most_common(1)[0][0] if g["prices"] else 0
        db.execute(
            """INSERT INTO components (category, manufacturer, part_number, description, supplier, cost, selling_price, stock)
               VALUES (?, ?, ?, ?, ?, ?, ?, 0)""",
            (g["cat"], g["mfr"], g["model"], g["desc"], "From BOM history", price, price))
    db.commit()
    return len(groups)


@app.route("/components/rebuild", methods=["POST"])
@roles_required("Admin")
def components_rebuild():
    n = rebuild_components(get_db())
    flash(f"Component database replaced: {n} components built from all BOMs.", "success")
    return redirect(url_for("components"))


# ---------------------------------------------------------------------------
# Step 4: BOMs (search -> create -> edit at ANY time -> clone to make another BOM)
# ---------------------------------------------------------------------------

def bom_totals_for(db, bom_ids):
    """{bom_id: totals} for a list of BOM ids."""
    out = {}
    for bid in bom_ids:
        bom = db.execute("SELECT * FROM boms WHERE id=?", (bid,)).fetchone()
        items = db.execute("SELECT * FROM bom_items WHERE bom_id=? ORDER BY id", (bid,)).fetchall()
        out[bid] = (items, compute_bom_totals(bom, items))
    return out


@app.route("/boms")
@login_required
def boms_list():
    """All existing BOMs with every component, qty and price visible; each can be edited or cloned."""
    db = get_db()
    q = request.args.get("q", "").strip()
    sql = """SELECT b.*, c.company FROM boms b LEFT JOIN customers c ON c.id = b.customer_id WHERE 1=1"""
    params = []
    if q:
        sql += """ AND (b.title LIKE ? OR b.bom_number LIKE ? OR c.company LIKE ? OR EXISTS
                   (SELECT 1 FROM bom_items i WHERE i.bom_id=b.id AND (i.part_number LIKE ? OR i.description LIKE ? OR i.category LIKE ?)))"""
        params += [f"%{q}%"] * 6
    sql += " ORDER BY b.id DESC"
    rows = db.execute(sql, params).fetchall()
    detail = bom_totals_for(db, [b["id"] for b in rows])
    return render_template("boms_list.html", boms=rows, detail=detail, q=q)


@app.route("/boms/search")
@login_required
def bom_search():
    """Keyword search over BOM title, customer, number AND every component line (CPU, motherboard, heatsink...).
    Each hit is shown with its COMPLETE bill of materials."""
    db = get_db()
    requirement_id = request.args.get("requirement_id", type=int)
    requirement = None
    q = request.args.get("q", "").strip()
    searched = "q" in request.args
    if requirement_id:
        requirement = db.execute("SELECT * FROM requirements WHERE id=?", (requirement_id,)).fetchone()
        if not q and requirement and not searched:
            q = requirement["title"] or ""

    similar = []
    words = [w for w in re.split(r"[\s,;]+", q) if len(w) > 1]
    if words:
        score_parts, params = [], []
        for w in words:
            score_parts.append(
                """(CASE WHEN b.title LIKE ? OR b.bom_number LIKE ? OR c.company LIKE ? OR EXISTS
                     (SELECT 1 FROM bom_items i WHERE i.bom_id=b.id AND (i.category LIKE ? OR i.manufacturer LIKE ?
                       OR i.part_number LIKE ? OR i.description LIKE ?)) THEN 1 ELSE 0 END)""")
            params += [f"%{w}%"] * 7
        score_sql = " + ".join(score_parts)
        # when several words are typed, show BOMs matching the most words first (but any single match qualifies)
        similar = db.execute(
            f"""SELECT * FROM (SELECT b.*, c.company, ({score_sql}) AS score FROM boms b
                    LEFT JOIN customers c ON c.id = b.customer_id
                    WHERE NOT EXISTS (SELECT 1 FROM boms n WHERE n.bom_number=b.bom_number AND n.version>b.version))
                WHERE score > 0 ORDER BY score DESC, id DESC""",
            params,
        ).fetchall()
    detail = bom_totals_for(db, [b["id"] for b in similar])
    return render_template("bom_search.html", requirement=requirement, similar=similar, q=q, words=words, detail=detail)


def inherited_owner(db, requirement_id, me):
    """(assigned_to, due_date) for a new BOM: the requirement's engineer, else the creator if an engineer."""
    if requirement_id:
        r = db.execute("SELECT assigned_to, due_date FROM requirements WHERE id=?", (requirement_id,)).fetchone()
        if r and r["assigned_to"]:
            return r["assigned_to"], r["due_date"]
    return (me["id"] if me and me["role"] == "Engineer" else None), None


def copy_items(db, from_bom, to_bom):
    for it in db.execute("SELECT * FROM bom_items WHERE bom_id=? ORDER BY id", (from_bom,)).fetchall():
        db.execute(
            """INSERT INTO bom_items (bom_id, component_id, category, manufacturer, part_number, description, quantity, unit_price)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (to_bom, it["component_id"], it["category"], it["manufacturer"], it["part_number"],
             it["description"], it["quantity"], it["unit_price"]),
        )


@app.route("/boms/new", methods=["GET", "POST"])
@login_required
def bom_new():
    """CREATE NEW BOM (empty structure) or copy/customize an existing one."""
    db = get_db()
    requirement_id = request.args.get("requirement_id", type=int)
    copy_from = request.args.get("copy_from", type=int)

    if request.method == "POST":
        customer_id = resolve_customer(db)
        if not customer_id:
            flash("Please select a customer, or enter the company name of the new customer.", "error")
            return redirect(request.url)
        requirement_id = request.form.get("requirement_id") or None
        bom_number = next_number(db, "boms", "bom_number", "BOM")
        me = current_user_row(db)
        owner = inherited_owner(db, requirement_id, me)
        cur = db.execute(
            """INSERT INTO boms (bom_number, version, requirement_id, customer_id, title, status,
                                  pricing_mode, margin_percent, gst_percent, created_by, created_at, assigned_to, due_date)
               VALUES (?, 1, ?, ?, ?, 'DRAFT', 'AUTOMATIC', 15, 18, ?, ?, ?, ?)""",
            (bom_number, requirement_id, customer_id, request.form.get("title"), session.get("user_name"),
             datetime.now().isoformat(timespec="seconds"), owner[0], owner[1]),
        )
        new_bom_id = cur.lastrowid
        src = request.form.get("copy_from", type=int)
        if src:
            copy_items(db, src, new_bom_id)
        db.commit()
        notify_event(db, "bom", new_bom_id, "BOM_NEW", "BOM created",
                     f"{me['name']} started a new BOM ({bom_number}).", actor=me)
        flash(f"BOM {bom_number} created. You can add and edit components below.", "success")
        return redirect(url_for("bom_detail", bom_id=new_bom_id))

    requirement = None
    if requirement_id:
        requirement = db.execute("SELECT * FROM requirements WHERE id=?", (requirement_id,)).fetchone()
    copy_bom = None
    items = []
    if copy_from:
        copy_bom = db.execute("SELECT * FROM boms WHERE id=?", (copy_from,)).fetchone()
        items = db.execute("SELECT * FROM bom_items WHERE bom_id=?", (copy_from,)).fetchall()
    customers_rows = db.execute("SELECT * FROM customers ORDER BY company").fetchall()
    return render_template("bom_new.html", requirement=requirement, customers=customers_rows,
                           copy_bom=copy_bom, copy_items=items)


@app.route("/boms/<int:bom_id>/clone", methods=["POST"])
@login_required
def bom_clone(bom_id):
    """Create ANOTHER BOM from an existing one (new BOM number, all components copied, draft)."""
    db = get_db()
    bom = db.execute("SELECT * FROM boms WHERE id=?", (bom_id,)).fetchone()
    if not bom:
        abort(404)
    bom_number = next_number(db, "boms", "bom_number", "BOM")
    title = (bom["title"] or "") + " (copy)"
    me = current_user_row(db)
    owner = inherited_owner(db, bom["requirement_id"], me)
    cur = db.execute(
        """INSERT INTO boms (bom_number, version, requirement_id, customer_id, title, status,
                              pricing_mode, margin_percent, gst_percent, created_by, created_at, assigned_to, due_date)
           VALUES (?, 1, ?, ?, ?, 'DRAFT', ?, ?, ?, ?, ?, ?, ?)""",
        (bom_number, bom["requirement_id"], bom["customer_id"], title, bom["pricing_mode"],
         bom["margin_percent"], bom["gst_percent"], session.get("user_name"),
         datetime.now().isoformat(timespec="seconds"), owner[0], owner[1]),
    )
    copy_items(db, bom_id, cur.lastrowid)
    db.commit()
    notify_event(db, "bom", cur.lastrowid, "BOM_NEW", "BOM created (copy)",
                 f"{me['name']} created {bom_number} as a copy of {bom['bom_number']}.", actor=me)
    flash(f"New BOM {bom_number} created from {bom['bom_number']}. Modify components as needed.", "success")
    return redirect(url_for("bom_detail", bom_id=cur.lastrowid))


def compute_bom_totals(bom, items):
    """All amounts are whole rupees."""
    subtotal = sum((it["quantity"] or 0) * (it["unit_price"] or 0) for it in items)
    margin_amount = round(subtotal * (bom["margin_percent"] or 0) / 100.0)
    selling = subtotal + margin_amount
    gst_amount = round(selling * (bom["gst_percent"] or 0) / 100.0)
    grand_total = selling + gst_amount
    return {
        "subtotal": int(subtotal), "margin_amount": int(margin_amount), "selling": int(selling),
        "gst_amount": int(gst_amount), "grand_total": int(grand_total),
    }


@app.route("/boms/<int:bom_id>")
@login_required
def bom_detail(bom_id):
    db = get_db()
    bom = db.execute("SELECT * FROM boms WHERE id=?", (bom_id,)).fetchone()
    if not bom:
        abort(404)
    items = db.execute("SELECT * FROM bom_items WHERE bom_id=? ORDER BY id", (bom_id,)).fetchall()
    totals = compute_bom_totals(bom, items)
    customer = db.execute("SELECT * FROM customers WHERE id=?", (bom["customer_id"],)).fetchone()
    customers_rows = db.execute("SELECT * FROM customers ORDER BY company").fetchall()
    versions = db.execute(
        """SELECT * FROM boms WHERE bom_number = (SELECT bom_number FROM boms WHERE id=?)
           ORDER BY version""",
        (bom_id,),
    ).fetchall()
    quote = db.execute("SELECT * FROM quotations WHERE bom_id=? ORDER BY id DESC LIMIT 1", (bom_id,)).fetchone()
    all_components = db.execute("SELECT * FROM components ORDER BY category, manufacturer").fetchall()
    return render_template(
        "bom_detail.html", bom=bom, items=items, totals=totals, customer=customer,
        customers=customers_rows, versions=versions, quote=quote, all_components=all_components
    )


def _bom_changed(db, bom_id):
    """After any edit: tell the user if a quotation already exists for this BOM."""
    q = db.execute("SELECT quote_number FROM quotations WHERE bom_id=? ORDER BY id DESC LIMIT 1", (bom_id,)).fetchone()
    if q:
        flash(f"Saved. Quotation {q['quote_number']} already exists for this BOM - open it and use "
              f"'Refresh from BOM' to carry these changes into the quotation.", "success")
    else:
        flash("BOM saved.", "success")


@app.route("/boms/<int:bom_id>/meta", methods=["POST"])
@login_required
def bom_meta(bom_id):
    db = get_db()
    customer_id = resolve_customer(db)
    db.execute("UPDATE boms SET title=?, customer_id=COALESCE(?, customer_id) WHERE id=?",
               (request.form.get("title"), customer_id, bom_id))
    db.commit()
    _bom_changed(db, bom_id)
    return redirect(url_for("bom_detail", bom_id=bom_id))


@app.route("/boms/<int:bom_id>/add_item", methods=["POST"])
@login_required
def bom_add_item(bom_id):
    db = get_db()
    component_id = request.form.get("component_id", type=int)
    quantity = to_int(request.form.get("quantity"), 1, minimum=1)
    if component_id:
        comp = db.execute("SELECT * FROM components WHERE id=?", (component_id,)).fetchone()
        db.execute(
            """INSERT INTO bom_items (bom_id, component_id, category, manufacturer, part_number, description, quantity, unit_price)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (bom_id, comp["id"], comp["category"], comp["manufacturer"], comp["part_number"],
             comp["description"], quantity, to_int(comp["selling_price"])),
        )
    else:
        db.execute(
            """INSERT INTO bom_items (bom_id, category, manufacturer, part_number, description, quantity, unit_price)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (bom_id, request.form.get("category"), request.form.get("manufacturer"),
             request.form.get("part_number"), request.form.get("description"),
             quantity, to_int(request.form.get("unit_price"))),
        )
    db.commit()
    _bom_changed(db, bom_id)
    return redirect(url_for("bom_detail", bom_id=bom_id))


@app.route("/boms/<int:bom_id>/save_items", methods=["POST"])
@login_required
def bom_save_items(bom_id):
    """Save every edited line of the BOM table in one go."""
    db = get_db()
    for item_id in request.form.getlist("item_id"):
        f = lambda name: request.form.get(f"{name}_{item_id}", "")
        db.execute(
            """UPDATE bom_items SET category=?, manufacturer=?, part_number=?, description=?, quantity=?, unit_price=?
               WHERE id=? AND bom_id=?""",
            (f("category"), f("manufacturer"), f("part_number"), f("description"),
             to_int(f("quantity"), 1, minimum=1), to_int(f("unit_price")), int(item_id), bom_id),
        )
    db.commit()
    _bom_changed(db, bom_id)
    return redirect(url_for("bom_detail", bom_id=bom_id))


@app.route("/boms/<int:bom_id>/remove_item/<int:item_id>", methods=["POST"])
@login_required
def bom_remove_item(bom_id, item_id):
    db = get_db()
    db.execute("DELETE FROM bom_items WHERE id=? AND bom_id=?", (item_id, bom_id))
    db.commit()
    _bom_changed(db, bom_id)
    return redirect(url_for("bom_detail", bom_id=bom_id))


@app.route("/boms/<int:bom_id>/pricing", methods=["POST"])
@login_required
def bom_pricing(bom_id):
    db = get_db()
    db.execute(
        "UPDATE boms SET pricing_mode=?, margin_percent=?, gst_percent=? WHERE id=?",
        (request.form.get("pricing_mode", "AUTOMATIC"),
         float(request.form.get("margin_percent") or 0), float(request.form.get("gst_percent") or 0), bom_id),
    )
    db.commit()
    _bom_changed(db, bom_id)
    return redirect(url_for("bom_detail", bom_id=bom_id))


@app.route("/boms/<int:bom_id>/submit_review", methods=["POST"])
@login_required
def bom_submit_review(bom_id):
    db = get_db()
    db.execute("UPDATE boms SET status='UNDER_REVIEW' WHERE id=?", (bom_id,))
    db.commit()
    me = current_user_row(db)
    add_remark(db, "bom", bom_id, me, "SYSTEM", "Submitted for internal review")
    db.commit()
    notify_event(db, "bom", bom_id, "BOM_SUBMIT", "BOM submitted for review",
                 f"{me['name']} submitted this BOM for admin review. Please approve it or request a revision.",
                 actor=me, to_assignee=True)
    flash("BOM submitted for internal review - admins have been e-mailed.", "success")
    return redirect(url_for("bom_detail", bom_id=bom_id))


@app.route("/boms/<int:bom_id>/reopen", methods=["POST"])
@login_required
def bom_reopen(bom_id):
    """Move a BOM back to Draft so it goes through review again after changes."""
    db = get_db()
    db.execute("UPDATE boms SET status='DRAFT' WHERE id=?", (bom_id,))
    db.commit()
    me = current_user_row(db)
    add_remark(db, "bom", bom_id, me, "SYSTEM", "Moved back to Draft")
    db.commit()
    notify_event(db, "bom", bom_id, "BOM_REOPEN", "BOM moved back to Draft",
                 f"{me['name']} moved this BOM back to Draft for changes.", actor=me)
    flash("BOM moved back to Draft.", "success")
    return redirect(url_for("bom_detail", bom_id=bom_id))


@app.route("/boms/<int:bom_id>/review", methods=["POST"])
@roles_required("Admin")
def bom_review_decision(bom_id):
    db = get_db()
    decision = request.form.get("decision")
    comment = request.form.get("comment", "")
    me = current_user_row(db)
    if decision == "approve":
        db.execute("UPDATE boms SET status='APPROVED', review_comment=? WHERE id=?", (comment, bom_id))
        add_remark(db, "bom", bom_id, me, "REMARK", "APPROVED" + (f": {comment}" if comment else ""))
        db.commit()
        notify_event(db, "bom", bom_id, "BOM_APPROVED", "BOM approved",
                     f"{me['name']} approved this BOM. A quotation can now be generated."
                     + (f"\n\nAdmin remark: {comment}" if comment else ""), actor=me)
        flash("BOM approved - the engineer has been e-mailed.", "success")
    else:
        bom = db.execute("SELECT * FROM boms WHERE id=?", (bom_id,)).fetchone()
        db.execute("UPDATE boms SET status='REVISION_REQUIRED', review_comment=? WHERE id=?", (comment, bom_id))
        cur = db.execute(
            """INSERT INTO boms (bom_number, version, parent_bom_id, requirement_id, customer_id, title,
                                  status, pricing_mode, margin_percent, gst_percent, created_by, created_at, remarks)
               VALUES (?, ?, ?, ?, ?, ?, 'DRAFT', ?, ?, ?, ?, ?, ?)""",
            (bom["bom_number"], bom["version"] + 1, bom_id, bom["requirement_id"], bom["customer_id"], bom["title"],
             bom["pricing_mode"], bom["margin_percent"], bom["gst_percent"], session.get("user_name"),
             datetime.now().isoformat(timespec="seconds"), comment),
        )
        new_id = cur.lastrowid
        db.execute("UPDATE boms SET assigned_to=?, due_date=?, assigned_by=?, assigned_at=? WHERE id=?",
                   (bom["assigned_to"], bom["due_date"], bom["assigned_by"], bom["assigned_at"], new_id))
        copy_items(db, bom_id, new_id)
        add_remark(db, "bom", bom_id, me, "REMARK", "REVISION REQUIRED" + (f": {comment}" if comment else ""))
        add_remark(db, "bom", new_id, me, "REMARK", "Revision requested" + (f": {comment}" if comment else ""))
        db.commit()
        notify_event(db, "bom", new_id, "BOM_REVISION", "Revision required",
                     f"{me['name']} reviewed {bom['bom_number']} v{bom['version']} and asked for changes. "
                     f"A new draft (v{bom['version'] + 1}) has been created for editing."
                     + (f"\n\nAdmin remark: {comment}" if comment else ""), actor=me)
        flash("Revision requested. A new draft version has been created for editing.", "error")
        return redirect(url_for("bom_detail", bom_id=new_id))
    db.commit()
    return redirect(url_for("bom_detail", bom_id=bom_id))


# ---------------------------------------------------------------------------
# Step 5: Quotation (format = Allway HPC Word quotation; editable any time)
# ---------------------------------------------------------------------------

DEFAULT_SUBJECT = "Quotation for High Performance Server / Workstation"
DEFAULT_TERMS = {
    "taxes": "GST @ 18% extra as mentioned in the above table",
    "warranty": "3 Years Standard warranty (only on hardware parts)",
    "payment": "100% Advance along with the PO",
    "delivery": "6-8 weeks from the date of receipt of PO; subject to stock availability at the time of Processing the PO.",
    "validity": "The Price Valid for 5 days",
    "order_to": "Must be placed on ALLWAY HPC PVT LTD",
}
TERM_LABELS = [("taxes", "Taxes"), ("warranty", "Warranty"), ("payment", "Payment"),
               ("delivery", "Delivery"), ("validity", "Validity"), ("order_to", "Order to be released on")]
SPEC_GROUPS = [("Overview", ["Make", "Model"]), ("Build", ["Chassis", "Chipset", "CPU", "Memory"]),
               ("Storage", ["SSD", "HDD", "Drive Bays"]),
               ("Expansion", ["Expansion Slots", "GPU", "Network", "Ports", "Add-on-Card"]),
               ("Power & OS", ["Power Supply", "Operating System"])]
SPEC_LABELS = quote_docx.SPEC_ROWS
DEFAULT_SPECS = {"Make": "AHPC", "Model": "AHPC-", "Ports": "2 x USB 3.2 Gen2, 1 x MLAN, 1 x VGA",
                 "Operating System": "Linux Operating System (Ubuntu / Rocky)"}
BOM_DERIVED = [l for l in SPEC_LABELS if l not in ("Make", "Model", "Ports", "Operating System", "Drive Bays", "Expansion Slots")]


def spec_row_for(item):
    """Which row of the proposal table a BOM line belongs to."""
    c = (item["category"] or "").lower()
    d = ((item["description"] or "") + " " + (item["part_number"] or "")).lower()
    if "chassis" in c: return "Chassis"
    if "mother" in c or "mainboard" in c: return "Chipset"
    if "heat" in c or "cooler" in c: return "CPU"
    if "cpu" in c or "processor" in c: return "CPU"
    if "memory" in c or c in ("ram", "dimm"): return "Memory"
    if "gpu" in c or "graphic" in c: return "GPU"
    if "hdd" in c or "hard" in c or "hdd" in d.split(): return "HDD"
    if "ssd" in c or "nvme" in c or "storage" in c or "disk" in c: return "SSD"
    if "nic" in c or "network" in c or "lan" in c: return "Network"
    if "hba" in c or "raid" in c or "controller" in c or "add" in c: return "Add-on-Card"
    if "psu" in c or "power" in c: return "Power Supply"
    return None


def build_specs(items, existing=None):
    specs = dict(DEFAULT_SPECS)
    if existing:
        for k in ("Make", "Model", "Drive Bays", "Expansion Slots", "Ports", "Operating System"):
            if existing.get(k):
                specs[k] = existing[k]
    buckets = {}
    for it in items:
        row = spec_row_for(it)
        if not row:
            continue
        name = " ".join(x for x in [(it["manufacturer"] or "").strip(), (it["part_number"] or "").strip()] if x)
        desc = (it["description"] or "").strip()
        if desc and desc.lower() not in name.lower():
            name = f"{name} - {desc}" if name else desc
        text = f"{int(it['quantity'] or 1)} x {name}".strip()
        if (it["category"] or "").lower().startswith(("heat", "cooler")):
            text = "Heatsink: " + text
        buckets.setdefault(row, []).append(text)
    for row, texts in buckets.items():
        specs[row] = "; ".join(texts)
    return specs


def new_quote_number(db):
    year = datetime.now().year
    like = f"{year}%"
    best = 1539  # the supplied format starts at 20260001539
    for (n,) in db.execute("SELECT quote_number FROM quotations WHERE quote_number LIKE ?", (like,)).fetchall():
        if re.fullmatch(r"\d{11}", n or ""):
            best = max(best, int(n[4:]))
    return f"{year}{best + 1:07d}"


def money_parts(total_price, gst_percent):
    total = to_int(total_price)
    gst = round(total * float(gst_percent or 0) / 100.0)
    return total, int(gst), int(total + gst)


def hydrate_quote(db, quote_id):
    """Make sure a quotation row has every field of the Word format (also upgrades quotes made by the old version)."""
    q = db.execute("SELECT * FROM quotations WHERE id=?", (quote_id,)).fetchone()
    if q is None:
        return None
    if q["specs"] is None:
        bom = db.execute("SELECT * FROM boms WHERE id=?", (q["bom_id"],)).fetchone()
        items = db.execute("SELECT * FROM bom_items WHERE bom_id=? ORDER BY id", (q["bom_id"],)).fetchall()
        cust = db.execute("SELECT * FROM customers WHERE id=?", (q["customer_id"],)).fetchone()
        gst_pct = bom["gst_percent"] if bom else 18
        total = compute_bom_totals(bom, items)["selling"] if bom else (q["subtotal"] or 0) + (q["margin_amount"] or 0)
        total, gst, grand = money_parts(total, gst_pct)
        terms = dict(DEFAULT_TERMS)
        terms["taxes"] = f"GST @ {gst_pct:g}% extra as mentioned in the above table"
        db.execute(
            """UPDATE quotations SET to_company=?, to_address=?, subject=?, specs=?, total_price=?, gst_percent=?,
               gst_amount=?, grand_total=?, quote_date=?, terms_json=?, updated_at=? WHERE id=?""",
            (cust["company"] if cust else "", (cust["address"] if cust else "") or "", DEFAULT_SUBJECT,
             json.dumps(build_specs(items)), total, gst_pct, gst, grand,
             (q["created_at"] or datetime.now().isoformat())[:10], json.dumps(terms),
             datetime.now().isoformat(timespec="seconds"), quote_id),
        )
        db.commit()
        q = db.execute("SELECT * FROM quotations WHERE id=?", (quote_id,)).fetchone()
    return q


def quote_context(q):
    """Plain dict used by the HTML page and the .docx filler."""
    specs = json.loads(q["specs"] or "{}")
    terms = dict(DEFAULT_TERMS)
    terms.update(json.loads(q["terms_json"] or "{}"))
    d = (q["quote_date"] or (q["created_at"] or "")[:10])
    try:
        shown = datetime.strptime(d, "%Y-%m-%d").strftime("%d/%m/%Y")
    except ValueError:
        shown = d
    return dict(
        id=q["id"], quote_number=q["quote_number"], date=shown, date_iso=d,
        to_company=q["to_company"] or "", to_address=q["to_address"] or "", subject=q["subject"] or DEFAULT_SUBJECT,
        specs={l: specs.get(l, "") for l in SPEC_LABELS}, terms=terms,
        total_price=q["total_price"] or 0, gst_percent=q["gst_percent"] if q["gst_percent"] is not None else 18,
        gst_amount=q["gst_amount"] or 0, grand_total=q["grand_total"] or 0,
        status=q["status"], remarks=q["remarks"] or "", bom_id=q["bom_id"],
    )


@app.route("/boms/<int:bom_id>/generate_quote", methods=["POST"])
@login_required
def generate_quote(bom_id):
    db = get_db()
    bom = db.execute("SELECT * FROM boms WHERE id=?", (bom_id,)).fetchone()
    if bom["status"] not in ("APPROVED", "QUOTED"):
        flash("BOM must be Admin Approved before generating a quotation.", "error")
        return redirect(url_for("bom_detail", bom_id=bom_id))
    items = db.execute("SELECT * FROM bom_items WHERE bom_id=?", (bom_id,)).fetchall()
    totals = compute_bom_totals(bom, items)
    quote_number = new_quote_number(db)
    cur = db.execute(
        """INSERT INTO quotations (quote_number, bom_id, customer_id, subtotal, margin_amount, gst_amount,
                                    grand_total, terms, status, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, '', 'DRAFT', ?)""",
        (quote_number, bom_id, bom["customer_id"], totals["subtotal"], totals["margin_amount"],
         totals["gst_amount"], totals["grand_total"], datetime.now().isoformat(timespec="seconds")),
    )
    db.execute("UPDATE boms SET status='QUOTED' WHERE id=?", (bom_id,))
    db.execute("UPDATE quotations SET assigned_to=?, due_date=? WHERE id=?",
               (bom["assigned_to"], bom["due_date"], cur.lastrowid))
    db.commit()
    hydrate_quote(db, cur.lastrowid)
    me = current_user_row(db)
    notify_event(db, "quote", cur.lastrowid, "QUOTE_NEW", "Quotation generated",
                 f"{me['name']} generated quotation {quote_number} from {bom['bom_number']} v{bom['version']}.", actor=me)
    flash(f"Quotation {quote_number} generated. You can still edit it.", "success")
    return redirect(url_for("quote_view", quote_id=cur.lastrowid))


@app.route("/quotes")
@login_required
def quotes_list():
    db = get_db()
    for r in db.execute("SELECT id FROM quotations WHERE specs IS NULL").fetchall():
        hydrate_quote(db, r["id"])
    rows = db.execute(
        """SELECT q.*, c.company FROM quotations q
           LEFT JOIN customers c ON c.id = q.customer_id ORDER BY q.id DESC"""
    ).fetchall()
    return render_template("quotes_list.html", quotes=rows)


@app.route("/quotes/<int:quote_id>")
@login_required
def quote_view(quote_id):
    db = get_db()
    q = hydrate_quote(db, quote_id)
    if not q:
        abort(404)
    return render_template("quote_view.html", q=quote_context(q), spec_groups=SPEC_GROUPS, term_labels=TERM_LABELS)


@app.route("/quotes/<int:quote_id>/edit", methods=["GET", "POST"])
@login_required
def quote_edit(quote_id):
    db = get_db()
    q = hydrate_quote(db, quote_id)
    if not q:
        abort(404)
    if request.method == "POST":
        f = request.form
        specs = {l: f.get("spec_" + l, "").strip() for l in SPEC_LABELS}
        terms = {k: f.get("term_" + k, "").strip() for k, _ in TERM_LABELS}
        gst_pct = float(f.get("gst_percent") or 0)
        total, gst, grand = money_parts(f.get("total_price"), gst_pct)
        db.execute(
            """UPDATE quotations SET quote_number=?, quote_date=?, to_company=?, to_address=?, subject=?, specs=?,
               total_price=?, gst_percent=?, gst_amount=?, grand_total=?, terms_json=?, status=?,
               updated_at=? WHERE id=?""",
            (f.get("quote_number") or q["quote_number"], f.get("quote_date"), f.get("to_company"),
             f.get("to_address"), f.get("subject"), json.dumps(specs), total, gst_pct, gst, grand,
             json.dumps(terms), f.get("status") or q["status"],
             datetime.now().isoformat(timespec="seconds"), quote_id),
        )
        db.commit()
        notify_event(db, "quote", quote_id, "QUOTE_EDIT", "Quotation edited",
                     f"{session.get('user_name')} edited the quotation.", actor=current_user_row(db))
        flash("Quotation updated.", "success")
        return redirect(url_for("quote_view", quote_id=quote_id))
    return render_template("quote_edit.html", q=quote_context(q), spec_groups=SPEC_GROUPS, term_labels=TERM_LABELS)


@app.route("/quotes/<int:quote_id>/refresh", methods=["POST"])
@login_required
def quote_refresh(quote_id):
    """Re-read the (edited) BOM into the quotation: configuration rows + price. Make/Model/Ports/OS are kept."""
    db = get_db()
    q = hydrate_quote(db, quote_id)
    bom = db.execute("SELECT * FROM boms WHERE id=?", (q["bom_id"],)).fetchone()
    items = db.execute("SELECT * FROM bom_items WHERE bom_id=? ORDER BY id", (q["bom_id"],)).fetchall()
    existing = json.loads(q["specs"] or "{}")
    specs = build_specs(items, existing)
    totals = compute_bom_totals(bom, items)
    total, gst, grand = money_parts(totals["selling"], bom["gst_percent"])
    terms = json.loads(q["terms_json"] or "{}")
    terms["taxes"] = f"GST @ {bom['gst_percent']:g}% extra as mentioned in the above table"
    db.execute(
        """UPDATE quotations SET specs=?, total_price=?, gst_percent=?, gst_amount=?, grand_total=?, subtotal=?,
           margin_amount=?, terms_json=?, updated_at=? WHERE id=?""",
        (json.dumps(specs), total, bom["gst_percent"], gst, grand, totals["subtotal"], totals["margin_amount"],
         json.dumps(terms), datetime.now().isoformat(timespec="seconds"), quote_id),
    )
    db.commit()
    flash("Quotation refreshed from the latest BOM.", "success")
    return redirect(url_for("quote_view", quote_id=quote_id))


@app.route("/quotes/<int:quote_id>/status", methods=["POST"])
@login_required
def quote_status(quote_id):
    db = get_db()
    status = "SENT" if request.form.get("status") == "SENT" else "DRAFT"
    db.execute("UPDATE quotations SET status=? WHERE id=?", (status, quote_id))
    db.commit()
    me = current_user_row(db)
    add_remark(db, "quote", quote_id, me, "SYSTEM", "Marked as sent to customer" if status == "SENT" else "Moved back to draft")
    db.commit()
    notify_event(db, "quote", quote_id, "QUOTE_STATUS", "Quotation sent to customer" if status == "SENT" else "Quotation moved back to draft",
                 f"{me['name']} marked this quotation as {'SENT to the customer' if status == 'SENT' else 'DRAFT'}.", actor=me)
    flash("Quotation marked as sent to customer." if status == "SENT" else "Quotation moved back to draft.", "success")
    return redirect(url_for("quote_view", quote_id=quote_id))


@app.route("/quotes/<int:quote_id>/docx")
@login_required
def quote_download_docx(quote_id):
    db = get_db()
    q = hydrate_quote(db, quote_id)
    if not q:
        abort(404)
    ctx = quote_context(q)
    data = quote_docx.build_docx(ctx)
    return send_file(io.BytesIO(data), as_attachment=True, download_name=f"Quotation_{ctx['quote_number']}.docx",
                     mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")


@app.route("/quotes/<int:quote_id>/pdf")
@login_required
def quote_download_pdf(quote_id):
    db = get_db()
    q = hydrate_quote(db, quote_id)
    if not q:
        abort(404)
    ctx = quote_context(q)
    pdf = quote_docx.docx_to_pdf(quote_docx.build_docx(ctx))
    if pdf is None:
        flash("PDF export needs LibreOffice on the server. Download the Word file and use Save as PDF instead.", "error")
        return redirect(url_for("quote_view", quote_id=quote_id))
    return send_file(io.BytesIO(pdf), as_attachment=True, download_name=f"Quotation_{ctx['quote_number']}.pdf",
                     mimetype="application/pdf")


def overdue_reminders():
    """Once a day, e-mail the assignee + admins about every pending item that is past its due date and ask for
    the reason for delay."""
    with app.test_request_context("/"):
        db = sqlite3.connect(DB_PATH)
        db.row_factory = sqlite3.Row
        try:
            today = date.today().isoformat()
            for p in pending_quotes(db):
                if not (p["overdue"] and p["assignee_id"]):
                    continue
                info = item_info(db, p["kind"], p["id"])
                if db.execute("SELECT 1 FROM email_log WHERE event='OVERDUE' AND ref=? AND substr(created_at,1,10)=?",
                              (info["ref"], today)).fetchone():
                    continue
                notify_event(db, p["kind"], p["id"], "OVERDUE", "OVERDUE - please give reason for delay",
                             f"This {info['label'].lower()} was due on {p['due']} and is still pending ({p['stage']}). "
                             f"Please open it and add a 'Reason for delay' remark with a revised due date.",
                             actor=None)
        finally:
            db.close()


def _reminder_loop():
    import time
    while True:
        try:
            if datetime.now().hour >= 9:
                overdue_reminders()
        except Exception as exc:
            print("[reminder] error:", exc)
        time.sleep(3600)


if __name__ == "__main__":
    init_db()
    import sys
    if "--reset-passwords" in sys.argv:
        _db = sqlite3.connect(DB_PATH)
        _db.row_factory = sqlite3.Row
        reset_team_passwords(_db)
        _db.close()
        for _n, _e, _r, _p in TEAM:
            print(f"   {_n:<15} {_r:<9} {_e:<30} {_p}")
        print(" All 5 passwords have been reset to the values above. Start the app normally with:  python app.py")
        sys.exit(0)
    print("=" * 70)
    print(" AHPC BOM & Quotation Management System")
    print(" Starting on http://localhost:5000")
    print("=" * 70)
    import threading
    threading.Thread(target=_reminder_loop, daemon=True).start()
    print(" Zoho mail:", "configured (" + notify.config()["user"] + ")" if notify.is_configured()
          else "NOT configured - e-mails are only logged. Edit the settings at the top of notify.py")
    app.run(host="0.0.0.0", port=5000, debug=False, use_reloader=False)
