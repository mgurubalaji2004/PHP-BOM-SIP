"""
Fills the ORIGINAL Allway HPC Word quotation template (templates_docx/quotation_template.docx)
with the data of a quotation, so the downloaded .docx is identical in layout to the
format supplied by the company (logo, header/footer, 4 pages, tables, terms, note).
"""
import copy
import io
import os
import subprocess
import tempfile

import docx

TEMPLATE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates_docx", "quotation_template.docx")

# Row order of the "Proposal for Server" table in the template (row 1..16)
SPEC_ROWS = [
    "Make", "Model", "Chassis", "Chipset", "CPU", "Memory", "SSD", "HDD", "Drive Bays",
    "Expansion Slots", "GPU", "Network", "Ports", "Add-on-Card", "Power Supply", "Operating System",
]
# category label shown in the first column (rowspan groups in the template)
SPEC_GROUPS = [("Overview", 2), ("Build", 4), ("Storage", 3), ("Expansion", 5), ("Power & OS", 2)]


def inr2(x):
    """Indian digit grouping with 2 decimals, e.g. 514050 -> 5,14,050.00"""
    x = float(x or 0)
    neg = x < 0
    s = f"{abs(x):.2f}"
    whole, dec = s.split(".")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        whole = ",".join(parts) + "," + tail
    return ("-" if neg else "") + whole + "." + dec


def _set_text(par, text, run_index=0):
    """Put `text` in one run of the paragraph (keeps that run's formatting), blank the others."""
    runs = par.runs
    if not runs:
        par.add_run(text)
        return
    for i, r in enumerate(runs):
        r.text = text if i == run_index else ""


def _set_cell(cell, text, like=None):
    par = cell.paragraphs[0]
    if par.runs:
        _set_text(par, text)
        return
    r = par.add_run(text)
    if like is not None and like.runs:
        src = like.runs[0]._r
        if src.rPr is not None:
            r._r.insert(0, copy.deepcopy(src.rPr))


def _find(doc, startswith):
    for p in doc.paragraphs:
        if p.text.strip().startswith(startswith):
            return p
    return None


def build_docx(q):
    """q: dict with keys quote_number, date, to_company, to_address, subject, specs{label:value},
    total_price, gst_percent, gst_amount, grand_total, terms{taxes,warranty,payment,delivery,validity,order_to},
    note (optional). Returns bytes of the filled .docx"""
    d = docx.Document(TEMPLATE)
    t_no, t_to, t_sub, t_spec, t_tot = d.tables[0], d.tables[1], d.tables[2], d.tables[3], d.tables[4]

    # Quotation no. + date
    c0, c1 = t_no.rows[0].cells
    p = c0.paragraphs[0]
    runs = p.runs
    runs[1].text = " No.: "
    runs[2].text = str(q["quote_number"])
    for r in runs[3:]:
        r.text = ""
    p = c1.paragraphs[0]
    runs = p.runs
    runs[0].text = "Date: " + q["date"]
    for r in runs[1:]:
        r.text = ""

    # TO block (paragraphs: TO / Company Name: / Address:)
    pars = t_to.rows[0].cells[0].paragraphs
    _set_text(pars[1], "Company Name: " + (q.get("to_company") or ""))
    _set_text(pars[2], "Address: " + (q.get("to_address") or ""))

    # Subject
    _set_text(t_sub.rows[0].cells[0].paragraphs[0], "Sub : " + (q.get("subject") or ""))

    # Spec table
    like = t_spec.rows[1].cells[2].paragraphs[0]  # "AHPC " cell – details style
    for i, label in enumerate(SPEC_ROWS, start=1):
        _set_cell(t_spec.rows[i].cells[2], q["specs"].get(label, ""), like)

    # Totals
    _set_cell(t_tot.rows[0].cells[2], inr2(q["total_price"]))
    _set_text(t_tot.rows[1].cells[0].paragraphs[0], f"GST @ {q['gst_percent']:g}%")
    _set_cell(t_tot.rows[1].cells[2], inr2(q["gst_amount"]))
    _set_cell(t_tot.rows[2].cells[2], inr2(q["grand_total"]))

    # Terms (last run of each numbered paragraph holds the editable text)
    T = q["terms"]
    p_tax = _find(d, "1.  Taxes")
    p_war = _find(d, "2.  Warranty")
    p_pay = _find(d, "3.  Payment")
    p_del = _find(d, "4.  Delivery")
    p_val = _find(d, "5.  Validity")
    p_ord = _find(d, "6.  Order to be released")
    p_tax.runs[3].text = T["taxes"]
    for r in p_tax.runs[4:]:
        r.text = ""
    p_war.runs[3].text = T["warranty"]
    p_pay.runs[3].text = T["payment"]
    # delivery: runs 3 (weeks) + 4 (rest); the template has a continuation paragraph
    nxt = p_del._p.getnext()
    p_del.runs[3].text = T["delivery"]
    p_del.runs[4].text = ""
    if nxt is not None and nxt.tag.endswith("}p") and "Processing the PO" in "".join(nxt.itertext()):
        nxt.getparent().remove(nxt)
    p_val.runs[3].text = T["validity"]
    p_ord.runs[3].text = T["order_to"]

    # NOTE box
    if q.get("note"):
        cell = d.tables[5].rows[0].cells[0]
        if len(cell.paragraphs) > 1 and cell.paragraphs[1].runs:
            _set_text(cell.paragraphs[1], q["note"])

    buf = io.BytesIO()
    d.save(buf)
    return buf.getvalue()


def docx_to_pdf(data):
    """Convert docx bytes to PDF bytes with LibreOffice if installed; returns None otherwise."""
    with tempfile.TemporaryDirectory() as td:
        src = os.path.join(td, "q.docx")
        with open(src, "wb") as f:
            f.write(data)
        for exe in ("soffice", "libreoffice"):
            try:
                subprocess.run([exe, "--headless", "--convert-to", "pdf", "--outdir", td, src],
                               check=True, capture_output=True, timeout=120)
                with open(os.path.join(td, "q.pdf"), "rb") as f:
                    return f.read()
            except Exception:
                continue
    return None
